// Project identifier: 9504853406CBAC39EE89AA3AD238AA12CA198043
// This is Project 2 Part A of UMich EECS 281, 2023 Fall, built by Guanyu (Tony) Zhang

#include "Battle.h"

int main(int argc, char* argv[]) {
	ios_base::sync_with_stdio(false);
	Battle battle(argc, argv);
	battle.init();
}