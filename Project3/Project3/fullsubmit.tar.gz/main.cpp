// 292F24D17A4455C1B5133EDD8C7CEAA0C9570A98
// This is Project 3 of EECS 281 Fall 2023 by Guanyu Zhang

#include "Bank.h"

int main(int argc, char* argv[]) {
	ios_base::sync_with_stdio(false);
	Bank bank(argc, argv);
	bank.init();
}